package com.example.tuticket

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class panta2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_panta2)
    }

    fun pantaprim2(view: View) {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}